//
//  SMCollectionViewFillLayout.m
//
// Copyright (c) 2015 Sudeep Jaiswal
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

#import "SMCollectionViewFillLayout.h"

// Thanks: http://damir.me/implementing-uicollectionview-layout

@interface SMCollectionViewFillLayout ()

@property (readonly, nonatomic) NSInteger numberOfItemsInCollectionView;
@property (assign, nonatomic) CGSize contentSize;
@property (copy, nonatomic) NSIndexSet *extraIndexes;
@property (copy, nonatomic) NSArray *itemAttributes;
@property (readonly, weak, nonatomic) NSNotificationCenter *notificationCenter;

- (void)setup;
- (void)setupDefaults;
- (void)prepareVerticalLayout;
- (void)prepareHorizontalLayout;

@end

@implementation SMCollectionViewFillLayout

- (instancetype)init
{
  self = [super init];
  if (self) {
    [self setup];
  }
  return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder
{
  self = [super initWithCoder:coder];
  if (self) {
    [self setup];
  }
  return self;
}

#pragma mark - Setup

- (void)setup
{
  [self setupDefaults];
  [self listenForOrientationChanges];
}

- (void)setupDefaults
{
  self.numberOfItemsInSide = 1;
  self.itemSpacing = 8.0f;
  self.direction = SMCollectionViewFillLayoutVertical;
  //self.stretchesLastItems = YES;
}

#pragma mark - Orientation

- (void)listenForOrientationChanges
{
  [self.notificationCenter addObserver:self selector:@selector(orientationDidChange:) name:UIDeviceOrientationDidChangeNotification object:nil];
}

- (void)orientationDidChange:(NSNotification *)note
{
  [self invalidateLayout];
}

- (void)dealloc
{
  [self.notificationCenter removeObserver:self];
}

- (NSNotificationCenter *)notificationCenter
{
  return [NSNotificationCenter defaultCenter];
}

#pragma mark - Overrides

- (void)prepareLayout
{
  [super prepareLayout];
  
  // read values from delegate if available
  if ([_delegate respondsToSelector:@selector(numberOfItemsInSide)])
  {
    _numberOfItemsInSide = [_delegate numberOfItemsInSide];
  }
  if ([_delegate respondsToSelector:@selector(itemLength)])
  NSAssert(_numberOfItemsInSide > 0, @"Collection view must have at least one item in row. Set 'numberOfItemsInSide'.");
  
  if ([_delegate respondsToSelector:@selector(itemLength)])
  {
    _itemLength = [_delegate itemLength];
  }
  if ([_delegate respondsToSelector:@selector(itemSpacing)])
  {
    _itemSpacing = [_delegate itemSpacing];
  }
  
  _itemAttributes = nil;
  _extraIndexes = nil;
  _contentSize = CGSizeZero;
  
  // store indexes of any extra items, if present
  NSInteger numberOfItems = self.numberOfItemsInCollectionView;
  NSInteger extraItems = numberOfItems % _numberOfItemsInSide;
  
  if (extraItems > 0)
  {
    NSMutableIndexSet *indexes = [[NSMutableIndexSet alloc] init];
    for (int i=0; i<extraItems; i++)
    {
      NSInteger idx = (numberOfItems - 1) - i;
      [indexes addIndex:idx];
    }
    _extraIndexes = indexes;
  }
  
  if (_direction == SMCollectionViewFillLayoutVertical) {
    [self prepareVerticalLayout];
  }
  else {
    [self prepareHorizontalLayout];
  }
}

- (void)prepareVerticalLayout
{
  CGFloat xOffset = _itemSpacing;
  CGFloat yOffset = _itemSpacing;
  CGFloat rowHeight = 0.0f;
  CGFloat contentWidth = 0.0f;
  CGFloat contentHeight = 0.0f;
  NSUInteger column = 0;
  NSInteger numberOfItems = self.numberOfItemsInCollectionView;
  NSMutableArray *layoutAttributes = [[NSMutableArray alloc] init];
  
  for (int i = 0; i < numberOfItems; i++)
  {
    CGFloat itemWidth = 0.0f;
    
    // calculate item size. extra items will have different widths
    if (_stretchesLastItems && _extraIndexes.count && [_extraIndexes containsIndex:i])
    {
      CGFloat availableSpaceForItems = self.collectionView.bounds.size.width - (2 * _itemSpacing) - ((_extraIndexes.count - 1) * _itemSpacing);
      itemWidth = availableSpaceForItems / _extraIndexes.count;
    }
    else
    {
      CGFloat availableSpaceForItems = self.collectionView.bounds.size.width - (2 * _itemSpacing) - ((_numberOfItemsInSide - 1) * _itemSpacing);
      itemWidth = availableSpaceForItems / _numberOfItemsInSide;
    }
    
    // by default, item height is equal to item width
    // if not setting default item width
    if (!_itemLength) {
      _itemLength = itemWidth;
    }
    CGSize itemSize = CGSizeMake(itemWidth, _itemLength);
    
    if (itemSize.height > rowHeight) {
      rowHeight = itemSize.height;
    }
    
    // create layout attributes objects
    NSIndexPath *indexPath = [NSIndexPath indexPathForItem:i inSection:0];
    UICollectionViewLayoutAttributes *attributes = [UICollectionViewLayoutAttributes layoutAttributesForCellWithIndexPath:indexPath];
    attributes.frame = CGRectIntegral(CGRectMake(xOffset, yOffset, itemSize.width, itemSize.height));
    [layoutAttributes addObject:attributes];
    
    // move 'x' for next item
    xOffset = xOffset + itemSize.width + _itemSpacing;
    column++;
    
    // if item was the last one in current row
    // special case handled for when number of items is lesser than
    // number of items in row
    if ((numberOfItems < _numberOfItemsInSide && column == numberOfItems) ||
        (column == _numberOfItemsInSide))
    {
      if (xOffset > contentWidth) {
        contentWidth = xOffset;
      }
      
      // reset
      column = 0;
      xOffset = _itemSpacing;
      yOffset += rowHeight + _itemSpacing;
    }
    
    // calculate content height
    UICollectionViewLayoutAttributes *lastAttributes = layoutAttributes.lastObject;
    contentHeight = lastAttributes.frame.origin.y + lastAttributes.frame.size.height;
    _contentSize = CGSizeMake(contentWidth, contentHeight + _itemSpacing);
    _itemAttributes = [NSArray arrayWithArray:layoutAttributes];
  }
}

- (void)prepareHorizontalLayout
{
  
    if(_direction == SMCollectionViewFillLayoutHorizontal && self.isHorizontalFill){
        
        //SMP: custom code for horizontal cell filling for Horizontal layout direction
        CGFloat xOffset = _itemSpacing;
        CGFloat yOffset = _itemSpacing;
        CGFloat columnWidth = 0.0f;
        CGFloat contentWidth = 0.0f;
        CGFloat contentHeight = 0.0f;
        NSUInteger row = 0;
        NSInteger numberOfItems = self.numberOfItemsInCollectionView;
        NSMutableArray *layoutAttributes = [[NSMutableArray alloc] init];
        
        NSUInteger column = 0;
        CGFloat rowHeight = 0.0f;
        CGFloat lastXOffset = 0.0;
        
        for (int i = 0; i < numberOfItems; i++)
        {
            CGFloat itemWidth = 0.0f;
            
            // calculate item size. extra items will have different widths
            if (_stretchesLastItems && _extraIndexes.count && [_extraIndexes containsIndex:i])
            {
                CGFloat availableSpaceForItems = self.collectionView.bounds.size.width - (2 * _itemSpacing) - ((_extraIndexes.count - 1) * _itemSpacing);
                itemWidth = availableSpaceForItems / _extraIndexes.count;                                                
            }
            else
            {
                CGFloat availableSpaceForItems = self.collectionView.bounds.size.width - (2 * _itemSpacing) - ((_numberOfItemsInSide - 1) * _itemSpacing);
                itemWidth = availableSpaceForItems / _numberOfItemsInSide;
            }
            
            // by default, item height is equal to item width
            // if not setting default item width
            if (!_itemLength) {
                _itemLength = itemWidth;
            }
            CGSize itemSize = CGSizeMake(itemWidth, _itemLength);
            
            if (itemSize.height > rowHeight) {
                rowHeight = itemSize.height;
            }
            
            
            // create layout attributes objects
            NSIndexPath *indexPath = [NSIndexPath indexPathForItem:i inSection:0];
            UICollectionViewLayoutAttributes *attributes = [UICollectionViewLayoutAttributes layoutAttributesForCellWithIndexPath:indexPath];
            attributes.frame = CGRectIntegral(CGRectMake(xOffset, yOffset, itemSize.width, itemSize.height));
            [layoutAttributes addObject:attributes];
            
            
            
            // move 'x' for next item
            xOffset = xOffset + itemSize.width + _itemSpacing;
            column++;
            
            
            // calculate content width
            UICollectionViewLayoutAttributes *lastAttributes = layoutAttributes.lastObject;
            
            // if item was the last one in current row
            // special case handled for when number of items is lesser than
            // number of items in row
            if ((numberOfItems < _numberOfItemsInSide && column == numberOfItems) ||
                (column == _numberOfItemsInSide))
            {
                if (xOffset > contentWidth) {
                    contentWidth = xOffset;
                }
                
                if (itemSize.height > rowHeight) {
                    rowHeight = itemSize.height;
                }
                
                // move 'y' for next item
                row++;
                
                float newY = lastAttributes.frame.origin.y + (lastAttributes.frame.size.height * 2) + _itemSpacing;
                if (newY > self.collectionView.frame.size.height)
                {
                    if (xOffset > contentWidth) {
                        contentWidth = xOffset;
                    }
                    
                    // reset
                    column = 0;
                    row = 0;
                    yOffset = _itemSpacing;
                    xOffset += columnWidth + _itemSpacing;
                    lastXOffset = xOffset - _itemSpacing;
                }
                else{
                    // reset
                    column = 0;
                    xOffset = lastXOffset + _itemSpacing;
                    yOffset += rowHeight + _itemSpacing;
                }
            }
            
            // calculate content width
            contentWidth = lastAttributes.frame.origin.x + lastAttributes.frame.size.width;
            
            //SMP
            CGSize prevContentSize = _contentSize;
            _contentSize = CGSizeMake(contentWidth + _itemSpacing, contentHeight);
            if(_contentSize.width < prevContentSize.width)
                _contentSize = prevContentSize;
            
            _contentSize.height = self.collectionView.frame.size.height; //to fix programatically scroll
            //---------------------------------
            
            _itemAttributes = [NSArray arrayWithArray:layoutAttributes];
        }
    }
    else{
        
        CGFloat xOffset = _itemSpacing;
        CGFloat yOffset = _itemSpacing;
        CGFloat columnWidth = 0.0f;
        CGFloat contentWidth = 0.0f;
        CGFloat contentHeight = 0.0f;
        NSUInteger row = 0;
        NSInteger numberOfItems = self.numberOfItemsInCollectionView;
        NSMutableArray *layoutAttributes = [[NSMutableArray alloc] init];
        
        for (int i = 0; i < numberOfItems; i++)
        {
            CGFloat itemHeight = 0.0f;
            
            // calculate item size. extra items will have different heights
            if (_stretchesLastItems && _extraIndexes.count && [_extraIndexes containsIndex:i])
            {
                CGFloat availableSpaceForItems = self.collectionView.bounds.size.height - (2 * _itemSpacing) - ((_extraIndexes.count - 1) * _itemSpacing);
                itemHeight = availableSpaceForItems / _extraIndexes.count;
            }
            else
            {
                CGFloat availableSpaceForItems = self.collectionView.bounds.size.height - (2 * _itemSpacing) - ((_numberOfItemsInSide - 1) * _itemSpacing);
                itemHeight = availableSpaceForItems / _numberOfItemsInSide;
            }
            
            // by default, item height is equal to item width
            // if not setting default item height
            if (!_itemLength) {
                _itemLength = itemHeight;
            }
            CGSize itemSize = CGSizeMake(_itemLength, itemHeight);
            
            if (itemSize.width > columnWidth) {
                columnWidth = itemSize.width;
            }
            
            // create layout attributes objects
            NSIndexPath *indexPath = [NSIndexPath indexPathForItem:i inSection:0];
            UICollectionViewLayoutAttributes *attributes = [UICollectionViewLayoutAttributes layoutAttributesForCellWithIndexPath:indexPath];
            attributes.frame = CGRectIntegral(CGRectMake(xOffset, yOffset, itemSize.width, itemSize.height));
            [layoutAttributes addObject:attributes];
            
            // move 'y' for next item
            yOffset = yOffset + itemSize.height + _itemSpacing;
            row++;
            
            // if item was the last one in current column
            // special case handled for when number of items is lesser than
            // number of items in row
            if ((numberOfItems < _numberOfItemsInSide && row == numberOfItems) ||
                (row == _numberOfItemsInSide))
            {
                if (xOffset > contentWidth) {
                    contentWidth = xOffset;
                }
                
                // reset
                row = 0;
                yOffset = _itemSpacing;
                xOffset += columnWidth + _itemSpacing;
            }
            
            // calculate content width
            UICollectionViewLayoutAttributes *lastAttributes = layoutAttributes.lastObject;
            contentWidth = lastAttributes.frame.origin.x + lastAttributes.frame.size.width;
            _contentSize = CGSizeMake(contentWidth + _itemSpacing, contentHeight);
            _itemAttributes = [NSArray arrayWithArray:layoutAttributes];
            
            //SMP
            _contentSize.height = self.collectionView.frame.size.height; //to fix programatically scroll
        }
    }
}

#pragma mark - Property getters

- (NSInteger)numberOfItemsInCollectionView
{
  return [self.collectionView numberOfItemsInSection:0];
}

- (CGSize)collectionViewContentSize
{
  return _contentSize;
}

- (UICollectionViewLayoutAttributes *)layoutAttributesForItemAtIndexPath:(NSIndexPath *)indexPath
{
  return _itemAttributes[indexPath.row];
}

- (NSArray *)layoutAttributesForElementsInRect:(CGRect)rect
{
  NSPredicate *predicate = [NSPredicate predicateWithBlock:^BOOL(UICollectionViewLayoutAttributes *evaluatedObject, NSDictionary *bindings)
                            {
                              return CGRectIntersectsRect(rect, evaluatedObject.frame);
                            }];
  return [_itemAttributes filteredArrayUsingPredicate:predicate];
}

#pragma mark - Property setters

- (void)setNumberOfItemsInSide:(NSInteger)numberOfItemsInSide
{
  if (_numberOfItemsInSide != numberOfItemsInSide)
  {
    _numberOfItemsInSide = numberOfItemsInSide;
    [self invalidateLayout];
  }
}

- (void)setItemLength:(CGFloat)itemLength
{
  if (_itemLength != itemLength)
  {
    _itemLength = itemLength;
    [self invalidateLayout];
  }
}

- (void)setItemSpacing:(CGFloat)itemSpacing
{
  if (_itemSpacing != itemSpacing)
  {
    _itemSpacing = itemSpacing;
    [self invalidateLayout];
  }
}

- (void)setDirection:(SMCollectionViewFillLayoutDirection)direction
{
  if (_direction != direction)
  {
    _direction = direction;
    [self invalidateLayout];
  }
}

@end
