//
//  AppDelegate.h
//  SMCollectionViewFillLayoutExample
//
//  Created by sudeep on 25/11/15.
//  Copyright © 2015 sudeep. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

